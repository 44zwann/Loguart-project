# Build Loguart APK dari HP Android

Proyek ini dapat dibangun di GitHub Actions tanpa laptop, setelah diunggah ke repositori GitHub.

1. Buat repositori baru di https://github.com/new (misalnya `LoguartAndroid`).
2. Di halaman repositori, pilih **Add file → Upload files** dan unggah isi folder `LoguartAndroid` (termasuk folder `.github/workflows`). Jika antarmuka seluler sulit mengunggah folder, aktifkan **Situs desktop** pada browser atau gunakan aplikasi GitHub yang mendukung unggahan.
3. Pastikan branch bernama `main` dan file `.github/workflows/build-apk.yml` ada di repositori.
4. Buka tab **Actions**, pilih **Build Loguart APK**, lalu tekan **Run workflow** jika belum berjalan otomatis setelah commit.
5. Buka hasil run yang selesai, gulir ke **Artifacts**, lalu unduh `Loguart-debug-APK`.
6. Ekstrak ZIP artefak, lalu buka `app-debug.apk` untuk memasang. Jika Android meminta izin, izinkan pemasangan dari sumber tersebut hanya untuk file yang Anda percaya.

Catatan: ini APK debug untuk uji coba. Dashboard awal bukan bukti koneksi ECU; jangan gunakan fitur penulisan mapping sampai protokol dan prosedur aman diverifikasi. Android 9+ cocok dengan minSdk 28 pada proyek ini.
