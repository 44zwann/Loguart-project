# Loguart Android — Starter v1

Native Android/Kotlin starter for the Loguart ECU dashboard.

## Current scope
- Dark professional dashboard shell
- RPM, temperature, throttle and battery placeholders (intentionally blank)
- Bluetooth enabled/permission check
- Mapping button locked; no ECU commands are sent

## Not implemented yet
- Bluetooth SPP socket/session
- ECU protocol parsing for BRT Juken 5+ / UNSGARAGE
- Live sensor decoding, logging persistence, graphing
- Reading/writing maps

## Build APK
1. Install Android Studio (current stable) and Android SDK Platform 35.
2. Open this `LoguartAndroid` folder in Android Studio.
3. Allow Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

Use only a test setup until the ECU protocol is documented and verified. Do not implement write/map commands based on guesses.
