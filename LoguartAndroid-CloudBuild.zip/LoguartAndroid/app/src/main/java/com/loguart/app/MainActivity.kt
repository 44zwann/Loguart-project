package com.loguart.app

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val bg = 0xFF0B0F14.toInt()
    private val panel = 0xFF151C24.toInt()
    private val lime = 0xFFB9F227.toInt()
    private val white = 0xFFF4F7FA.toInt()
    private val muted = 0xFF9BA7B4.toInt()
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        setContentView(buildScreen())
    }

    private fun buildScreen(): ScrollView {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(bg)
        }
        page.addView(text("LOGUART", 30, lime, true))
        page.addView(text("ECU TUNING SYSTEM  •  V1.0", 12, muted, true))
        page.addView(gap(22))
        status = text("●  ECU NOT CONNECTED", 15, 0xFFFFC857.toInt(), true)
        page.addView(card(status))
        page.addView(gap(14))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(metric("ENGINE RPM", "—", "rpm"), weight())
        row1.addView(gapWidth(10))
        row1.addView(metric("ENGINE TEMP", "—", "°C"), weight())
        page.addView(row1)
        page.addView(gap(10))
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(metric("THROTTLE", "—", "%"), weight())
        row2.addView(gapWidth(10))
        row2.addView(metric("BATTERY", "—", "V"), weight())
        page.addView(row2)
        page.addView(gap(18))
        page.addView(card(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(text("LIVE DATA", 16, white, true))
            addView(gap(8))
            addView(text("Belum ada data ECU. Grafik akan aktif setelah protokol terverifikasi dan data nyata tersedia.", 13, muted, false))
        }))
        page.addView(gap(18))

        page.addView(actionButton("PERIKSA BLUETOOTH", lime) { checkBluetooth() })
        page.addView(gap(8))
        page.addView(actionButton("LOGGING  ·  SEGERA HADIR", panel) {
            Toast.makeText(this, "Fitur logging masuk tahap berikutnya.", Toast.LENGTH_SHORT).show()
        })
        page.addView(gap(8))
        page.addView(actionButton("MAPPING ECU  ·  TERKUNCI", panel) {
            Toast.makeText(this, "Mapping dinonaktifkan sampai protokol ECU terverifikasi.", Toast.LENGTH_LONG).show()
        })
        page.addView(gap(18))
        page.addView(text("Versi awal: dashboard UI. Tidak mengirim perintah ke ECU.", 12, muted, false))
        return ScrollView(this).apply { setBackgroundColor(bg); addView(page) }
    }

    private fun metric(label: String, value: String, unit: String): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(16), dp(14), dp(16))
        setBackgroundColor(panel)
        addView(text(label, 11, muted, true))
        addView(gap(8))
        addView(text(value, 28, white, true))
        addView(text(unit, 12, muted, false))
    }

    private fun card(content: android.view.View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(15), dp(15), dp(15), dp(15))
        setBackgroundColor(panel)
        addView(content)
    }

    private fun actionButton(label: String, color: Int, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        isAllCaps = false
        setTextColor(if (color == lime) bg else white)
        setBackgroundColor(color)
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52))
    }

    private fun checkBluetooth() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 42)
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        when {
            adapter == null -> Toast.makeText(this, "Perangkat ini tidak mendukung Bluetooth.", Toast.LENGTH_LONG).show()
            !adapter.isEnabled -> Toast.makeText(this, "Aktifkan Bluetooth melalui Pengaturan Android, lalu coba lagi.", Toast.LENGTH_LONG).show()
            else -> Toast.makeText(this, "Bluetooth aktif. Koneksi SPP dan protokol ECU belum diimplementasikan.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 42 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) checkBluetooth()
        else if (requestCode == 42) Toast.makeText(this, "Izin Bluetooth diperlukan untuk tahap koneksi.", Toast.LENGTH_LONG).show()
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply {
        text = value; textSize = size.toFloat(); setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }
    private fun gap(h: Int) = android.view.View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun gapWidth(w: Int) = android.view.View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
    private fun weight() = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
}
